# A simple drawing canvas.
let app = window("MINT Graphics", 640, 420)
let art = canvas(app, 580, 340, 24, 24)

draw_rect(art, 20, 20, 180, 100, "#3B82F6")
draw_circle(art, 300, 90, 55, "#F59E0B")
draw_line(art, 20, 170, 500, 250, "#16A34A")
draw_text(art, "Art created with MINT", 20, 280, "#111827")

show(app)
