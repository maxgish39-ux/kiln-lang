# Read text entered into a desktop input field.
let app = window("MINT Input Demo", 480, 220)
label(app, "What's your name?", 24, 24)
let name = text_input(app, 24, 58, 30)

fun greet() {
    print("Hello " + get_value(name))
}

button(app, "Greet", 24, 100, greet)
show(app)
