# Click the canvas to draw circles at the pointer location.
let app = window("MINT Interactive Canvas", 640, 440)
let art = canvas(app, 580, 360, 24, 24)

fun clicked(x, y) {
    draw_circle(art, x, y, 12, "#3B82F6")
}

fun clear_art() {
    clear_canvas(art)
}

on_click(art, clicked)
button(app, "Clear", 24, 395, clear_art)
show(app)
